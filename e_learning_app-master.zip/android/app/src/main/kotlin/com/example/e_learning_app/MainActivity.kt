package com.example.e_learning_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
