import 'package:flutter/material.dart';

class Achievement {
  final String title;
  final String description;
  final int stars;
  final Color color;

  Achievement({
    required this.title,
    required this.description,
    required this.stars,
    required this.color,
  });
}

class AchievementsScreen extends StatelessWidget {
  final List<Achievement> achievements = [
    Achievement(
      title: 'Studious',
      description: 'You have completed this lesson 10 times.',
      stars: 3,
      color: Colors.lightBlue,
    ),
    Achievement(
      title: 'Quickie',
      description:
          'You have completed this quiz in less than 3 minutes, 10 times.',
      stars: 4,
      color: Colors.amber,
    ),
    Achievement(
      title: 'Ambitious',
      description: 'You have achieved 15 milestones.',
      stars: 2,
      color: Colors.teal,
    ),
    Achievement(
      title: 'Perfectionist',
      description: 'You have scored 100% on quizzes 20 times.',
      stars: 3,
      color: Colors.blue,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Achievement'),
        actions: [
          IconButton(
            icon: Icon(Icons.menu),
            onPressed: () {
              // Handle menu action
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Card(
              elevation: 2,
              child: ListTile(
                leading: CircularProgressIndicator(
                  value: 0.8,
                  backgroundColor: Colors.grey[200],
                  color: Colors.green,
                ),
                title: Text('Total Achievements : 20'),
                subtitle:
                    Text('Great job, John! Complete your achievements now'),
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: achievements.length,
                itemBuilder: (context, index) {
                  final achievement = achievements[index];
                  return Card(
                    color: achievement.color,
                    child: ListTile(
                      leading: Icon(Icons.star, size: 40),
                      title: Text(achievement.title,
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text(achievement.description),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: List.generate(5, (starIndex) {
                          return Icon(
                            starIndex < achievement.stars
                                ? Icons.star
                                : Icons.star_border,
                            color: Colors.orange,
                          );
                        }),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 2, // Achievement tab is selected
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.book),
            label: 'Learn',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            label: 'Search',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.emoji_events),
            label: 'Achievement',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        onTap: (index) {
          // Handle navigation
        },
      ),
    );
  }
}
