import 'package:flutter/material.dart';
import 'package:e_learning_app/constants.dart';

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Profile'),
        backgroundColor: kblue,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushNamedAndRemoveUntil(
                context, '/home', (route) => false);
          },
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.menu),
            onPressed: () {
              // Add menu action
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            CircleAvatar(
              radius: 50,
              backgroundImage: AssetImage('assets/images/profile.png'),
            ),
            const SizedBox(height: 10),
            Text(
              'John Doe',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 5),
            Text(
              'Newbie',
              style: TextStyle(
                color: Colors.grey,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  children: [
                    Text(
                      '2+',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text('hours'),
                  ],
                ),
                Column(
                  children: [
                    Text(
                      '20',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text('Achievements'),
                  ],
                ),
                Column(
                  children: [
                    Text(
                      '2',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text('Languages'),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: Icon(Icons.settings, color: kblue),
              title: Text('Settings'),
              onTap: () {
                // Navigate to settings
              },
            ),
            ListTile(
              leading: Icon(Icons.star, color: kblue),
              title: Text('Achievements'),
              trailing: Container(
                padding: const EdgeInsets.all(5.0),
                decoration: BoxDecoration(
                  color: Colors.red,
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Text(
                  '2 New',
                  style: TextStyle(color: Colors.white),
                ),
              ),
              onTap: () {
                // Navigate to achievements
              },
            ),
            ListTile(
              leading: Icon(Icons.lock, color: kblue),
              title: Text('Privacy'),
              onTap: () {
                // Navigate to privacy settings
              },
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: Icon(Icons.switch_account, color: kblue),
              title: Text('Switch to Another Account'),
              onTap: () {
                // Switch account action
              },
            ),
            ListTile(
              leading: Icon(Icons.logout, color: kblue),
              title: Text('Logout Account'),
              onTap: () {
                // Logout action
              },
            ),
          ],
        ),
      ),
    );
  }
}
